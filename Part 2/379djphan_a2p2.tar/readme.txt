Note: The file_client must input an ip in the form of (255.255.255.255) not (@cs.blah.ualberta.ca). Does not work if so.
